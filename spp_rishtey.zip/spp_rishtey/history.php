<?php
include 'koneksi.php';
include 'header.php';

?>
<div class="container">
	<div class="page_header">
<h2> CARI SISWA BERDASARKAN NIS</h2>
	</div>
<form action ="" method="get">
	<table class="table">
		<tr>
			<td>NIS</td>
			<td>:</td>
			<td>
				<input class="from_control" type="text" name="nis">
			</td>
			<td>
				<button class="btn btn_success" type="submit" name="cari">Cari</button>
			</td>
		</tr>
	</table>
</form>
<?php
if (isset($_GET['nis']) && $_GET['nis'] !='')
	$data = $konek->query("SELECT * FROM siswa WHERE nis = '$_GET[nis]'");
	$query = mysqli_fetch_assoc($sql);
	$nis = $data['nis'];

?>
<div class="panel panel_info">
	<div class="panel_heading">
		<h3> Biodata Siswa </h3>
	</div>
	<div class="panel panel-body">
		<table class="table table_bordered table-striped">
			<tr>
				<td>NISN</td>
				<td><?= $data['nisn'] ?></td>
		</tr>
			<tr>
			<td>NIS</td>
			<td><?= $data['nis'] ?></td>
		</tr>
			<tr>
			<td>Nama Siswa</td>
			<td><?= $data['namasiswa'] ?></td>
		</td>
			<tr>
			<td>Kelas</td>
			<td><?= $data['kelas'] ?></td>
		</tr>
		<tr>
			<td>Tahun Ajaran</td>
			<td><?= $data['tahunajaran'] ?></td>
		</tr>
	</tr>
</table>
</div>
</div>

<div class="panel panel-info">
		<div calss="panel-heading">
			<h3>Tagihan SPP Siswa</h3>
		</div>
		<div class="panel-body">
			<table class="table table-bordered table-striped">
<tr>
	<th>No</th>
	<th>Bulan</th>
	<th>jatuh</th>
	<th>No Bayar</th>
	<th>Tanggal Bayar</th>
	<th>Jumlah</th>
	<th>keterangan</th>
	<th>bayar</th>
</tr>
<?php
$sql= mysqli_query($koneksi ,"SELECT * FROM spp Where id_sp='$data[id_spp]'");
$i=1;
while($sql = mysqli_fetch_assoc($sql)){
	echo "
		<tr>
			<td>$i</td>
			<td>$sq[bulan]</td>
			<td>$sq[jatuhtempo]</td>
			<td>$sq[nobayar]</td>
			<td>$sq[tglbayar]</td>
			<td>$sq[jumlah]</td>
			<td>$sq[ket]</td>
			<td align='center'";
				if($sq['nobayar'] == ''){
					echo "<a href='proses_transaksi.php?nis=$nis&act=bayar&id=$sq[id_spp]'></a> ";
					echo "<a class= 'btn btn primary btn-sm' href='proses_transaksi.php?nis=$nis&act=bayar&id=$sq[id_spp]'>Bayar</a>";
				}else {
					echo "</a>";
					echo "<a class= 'btn-danger btn-sm' href='proses_transaksi.php?nis=$nis&act=batal&id=$sq[id_spp]'>Batal</a>";
					echo "<a class= 'btn-danger btn-sm' href='cetak_slip_tarsaksi.php?nis=$nis&act=batal&id=$sq[id_spp]' target='_blank'>cetak</a>";
		}
		echo "</td>
		</tr>

		";
		$i++;
	}
	?>
</table>
</div>
</div>
<?php
?>
<p style="color: pink;"> pembayar dilakukan dengan cara mencari tagihan siswa berdasarkan nis </p>